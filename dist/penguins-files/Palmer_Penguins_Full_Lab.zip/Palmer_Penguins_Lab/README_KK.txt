PALMER PENGUINS — ТӨРТ МОДЕЛЬДІ САЛЫСТЫРУ
Орындаған: Қуат Ақылбек

НЕ ДАЙЫН?
1. Palmer_Penguins_4_Models_Akylbek.ipynb — орындалған Colab/Jupyter файлы.
2. palmer_penguins_4_models.py — сол жұмыстың Python коды.
3. penguins.csv — ресми деректердің қолданылған көшірмесі.
4. results — салыстыру кестелері, барлық test болжамдары, графиктер және қорытынды.
5. requirements.txt — осы іске қосудағы кітапхана нұсқалары.

COLAB-ТА АШУ
Google Colab → File → Upload notebook → .ipynb файлын таңдау.
Runtime → Run all. CSV жоқ болса, код ресми дереккөзден өзі жүктейді.
Орындамай-ақ сақталған нәтижелер мен графиктерді көруге болады.

КОМПЬЮТЕРДЕ ІСКЕ ҚОСУ
Архивті ашып, сол бумада терминал ашыңыз:
python -m pip install -r requirements.txt
python palmer_penguins_4_models.py

ӘДІСТЕМЕ
Бастапқы 344 жолдың қажетті өлшемдері жоқ 2 жолы алынды.
342 пингвин: train 273, test 69. random_state=42, stratify=y.
Төрт сандық белгі: bill_length_mm, bill_depth_mm, flipper_length_mm, body_mass_g.
Гиперпараметрлер тек train ішіндегі бірдей бес fold арқылы таңдалды.

НӘТИЖЕ
Decision Tree Classifier: 69/69 = 100%.
Random Forest: 69/69 = 100%.
Decision Tree Regressor (one-hot + argmax): 69/69 = 100%.
XGBoost Classifier: 66/69 = 95.65%.
Осы test бойынша алғашқы үш модель тең. Train-CV бойынша XGBoost алда (97.08%).
Бір бөліністегі бұл айырмашылық жалпы артықшылықтың дәлелі емес.

REGRESSOR ТУРАЛЫ
Түрлерді 0, 1, 2 деп регрессияға беріп дөңгелектемейміз.
DecisionTreeRegressor үш one-hot бағанын болжайды, argmax түрді таңдайды.
Бұл оқу мақсатындағы классификация бейімдеуі; кәдімгі Regressor Accuracy-і емес.
One-hot squared error Gini-ге пропорционал, сондықтан екі ағаштың нәтижесі тең болуы мүмкін.
Қосымша бөлімде дене массасын шынайы регрессия арқылы болжаймыз:
XGBoost Regressor RMSE = 309.10 г, Decision Tree Regressor RMSE = 354.27 г.
Бұл екі RMSE өзара салыстырылады, түрді танудағы Accuracy-мен салыстырылмайды.

ДЕРЕККӨЗ
https://github.com/allisonhorst/palmerpenguins
https://raw.githubusercontent.com/allisonhorst/palmerpenguins/main/inst/extdata/penguins.csv
Деректер: Kristen Gorman және Palmer Station LTER, CC0.
CSV хэші, кітапхана нұсқалары, нақты train/test жолдары results/experiment.json ішінде.
Кітапхана нұсқалары өзгерсе, нәтиже аздап өзгеруі мүмкін.
