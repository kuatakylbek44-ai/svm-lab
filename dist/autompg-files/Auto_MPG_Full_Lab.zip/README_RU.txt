Auto MPG — Kuat Akylbek / ML LAB

Откройте Auto_MPG_4_Models_Akylbek.ipynb в Google Colab и выполните все ячейки.
Для Python: pip install -r requirements.txt
Затем: python auto_mpg_4_models.py

398 исходных автомобилей. 7 входных признаков. Цель mpg непрерывная.
Сохраняем все строки;6 пропусков horsepower обрабатываются внутри каждого CV fold.
Train318/test80, seed42; одинаковые5 folds и8 комбинаций для каждой модели.
Decision Tree, Random Forest, Gradient Boosting, XGBoost — все регрессоры.
MAE/RMSE выражены в MPG; R² не означает процент правильных ответов.
Никаких Accuracy или классификационной матрицы ошибок для этой задачи.

Файлы:
- auto-mpg.data: неизменённый официальный UCI source.
- auto_mpg.csv: та же таблица с заголовками;? представлены пустыми значениями.
- results/: реальные метрики,80 test прогнозов, графики и параметры.
- notebook содержит реально выполненные outputs.

Источник: Quinlan, R. (1993). Auto MPG. UCI. https://doi.org/10.24432/C5859H
Лицензия данных: CC BY4.0; преобразование в CSV.
По train-CV выбрана Gradient Boosting. Минимальный test RMSE у Random Forest: 2.157 MPG. Это результат конкретного разбиения 318/80, а не гарантия на будущих автомобилях. MPG — мили на галлон: больше MPG означает лучшую топливную экономичность. MAE и RMSE — ошибки в MPG; R² не является процентом правильных ответов.
