ML LAB — Imbalanced Data

Colab: open Imbalanced_Data_Lab.ipynb and Run all.
Local: pip install -r requirements.txt; python Imbalanced_Data_Lab.py
No CSV is needed. The synthetic dataset is generated in the code.

1000 examples, 20 features, 90/10 classes, stratified 800/200 split.
Minority class = 1. Resample only train; the 200 test examples stay unchanged.
Methods: baseline, random oversampling, random undersampling, explicit SMOTE, balanced class weights.
All methods use RandomForestClassifier with 100 trees and random_state=42.
SMOTE uses interpolation between minority nearest neighbours.
Threshold adjustments are for teaching; choose an operating threshold on separate validation data.
