ML LAB — Week 10

Colab: open Unsupervised_Full_Lab.ipynb and Run all.
Local: pip install -r requirements.txt; python Unsupervised_Full_Lab.py
Keep new.csv next to the script. The seven lesson code cells retain their computed outputs.

Data: user-supplied new.csv (2240 rows, 29 original columns).
Features: Income, Recency, Spending (sum of 6 product totals), NumWebPurchases, NumStorePurchases, NumCatalogPurchases.
24 missing Income values: median imputation; all rows retained. No ID/Response/category inputs.
Customer KMeans: 6D, n_init=10, seed=22, K=2..8; PCA display only.
Silhouette is on a fixed sample of 500, seed=42. Raw and standardized models differ.
Page 4 customer PCA: all 2240 rows, six numerical features, 1-6 components, raw/scaled alternatives.
Colours are KMeans K=5 groups fitted in six dimensions at the selected scale, not known labels.
Page 7 customer PCA/t-SNE: all 2240 new.csv rows, the same six standardized features as customer clustering.
Colours are KMeans K=5 groups (seed22, n_init10), not true customer labels.
t-SNE: perplexity 5/30/50, seed42, PCA initialization, learning_rate=auto, max_iter=1000.

Imbalanced Data is now a separate topic with its own notebook and script.
